from .import myModule

